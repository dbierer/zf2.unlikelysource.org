<?php
return array(
	'db' => array(
		'driver' => 'pdo',
		'dsn' => 'mysql:dbname=onlinemarket;host=localhost',
		'username' => 'zend',
		'password' => 'password',
		'driver_options' => array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION),		
	),
	'service_manager' => array(
		'factories' => array(
			'general-adapter' => 'Zend\Db\Adapter\AdapterServiceFactory',
		),
	),	
);