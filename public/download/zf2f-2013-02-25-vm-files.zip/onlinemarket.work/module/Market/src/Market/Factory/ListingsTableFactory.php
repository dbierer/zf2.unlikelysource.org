<?php
namespace Market\Factory;

use Market\Model\ListingsTable;
use Zend\ServiceManager\ServiceLocatorInterface;
use Zend\ServiceManager\FactoryInterface;

class ListingsTableFactory implements FactoryInterface
{
	public function createService(ServiceLocatorInterface $serviceManager)
	{
		$adapter = $serviceManager->get('general-adapter');
		return new ListingsTable(ListingsTable::$tableName, $adapter);
	}
}