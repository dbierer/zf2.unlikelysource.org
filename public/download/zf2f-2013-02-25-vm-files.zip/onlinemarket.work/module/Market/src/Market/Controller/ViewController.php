<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/Market for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Market\Controller;

use Zend\View\Model\ViewModel;
use Zend\Mvc\Controller\AbstractActionController;

class ViewController extends AbstractActionController
{
	public $listings = 'LIST OF ITEMS';
	public $listingsTable;
	public function indexAction()
    {
       	$category = $this->params()->fromRoute('category');
    	if ($category) {
    		$listing = $this->listingsTable->getListingsByCategory($category);
    		$viewModel = new ViewModel(array('category' => $category, 'listing' => $listing));
    		$viewModel->setTemplate('market/view/index.phtml'); 
    		return $viewModel;
    	} else {
    		$this->flashMessenger()->addMessage('Category Not Found!');
    		return $this->redirect()->toRoute('home');
    	}
    }
    public function itemAction()
    {
       	$id = (int) $this->params()->fromRoute('id');
       	$item = $this->listingsTable->getListingById($id);
    	if ($id) {
    		$viewModel = new ViewModel(array('item' => $item, 'header' => 'Item Listing'));
    		$viewModel->setTemplate('market/view/item.phtml'); 
    		return $viewModel;
    	} else {
    		$this->flashMessenger()->addMessage('Item Not Found!');
    		return $this->redirect()->toRoute('home');
    	}
    }
    
}
