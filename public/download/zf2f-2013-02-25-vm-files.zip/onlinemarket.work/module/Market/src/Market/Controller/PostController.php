<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/Market for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Market\Controller;

use Zend\View\Model\ViewModel;
use Zend\Mvc\Controller\AbstractActionController;

class PostController extends AbstractActionController
{
	public $categories = array();
	public $postForm;
	public $postFormFilter;
	public $listingsTable;
	
    public function indexAction()
    {
    	$this->postForm->setAttributes(array(
    			'action' => $this->url()->fromRoute('market-post'),
    			'method' => 'POST'));
    	$this->postForm->setInputFilter($this->postFormFilter);
	    $data = $this->params()->fromPost();
    	$viewModel = new ViewModel(array(
    			'categories' => $this->categories,
    			'postForm' => $this->postForm, 
    			'data' => $data));
    	$viewModel->setTemplate('market/post/index.phtml');
    	$returnView = $viewModel; 
    	if ($this->getRequest()->isPost()) {
	    	$this->postForm->setData($data);
    		if ($this->postForm->isValid()) {
    			if ($this->listingsTable->addPosting($this->postForm->getData())) {
	    			$this->flashMessenger()->addMessage('Successful Posting!');
    			} else {
    				$this->flashMessenger()->addMessage('Unable to post your listing!');
    			}
    			$this->redirect()->toRoute('home');
    		} else {
    			$returnView = new ViewModel();
    			$returnView->setTemplate('market/post/invalid.phtml');
    			$returnView->addChild($viewModel, 'main');
    		}
    	}
        return $returnView;
    }

}
