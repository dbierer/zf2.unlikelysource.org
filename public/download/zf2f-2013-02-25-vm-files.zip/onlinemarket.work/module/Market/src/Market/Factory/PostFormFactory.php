<?php
namespace Market\Factory;

use Market\Form\PostForm;
use Zend\ServiceManager\ServiceLocatorInterface;
use Zend\ServiceManager\FactoryInterface;

class PostFormFactory implements FactoryInterface
{
	public function createService(ServiceLocatorInterface $serviceManager)
	{
		$categories = $serviceManager->get('application-categories');
		$formCategories = array();
		foreach ($categories as $key) {
			$formCategories[$key] = $key;
		}
		$form = new PostForm();
		$form->prepareElements($formCategories);
		return $form;
	}
}