<?php
namespace Market\Factory;

use Market\Controller\IndexController;
use Zend\ServiceManager\ServiceLocatorInterface;
use Zend\ServiceManager\FactoryInterface;

class IndexControllerFactory implements FactoryInterface
{
	public function createService(ServiceLocatorInterface $controllerManager)
	{
		$serviceManager = $controllerManager->getServiceLocator()->get('ServiceManager');
		$controller = new IndexController();
		$controller->listingsTable = $serviceManager->get('market-listings-table');
		return $controller;
	}
}