<?php
namespace Market\Factory;

use Market\Form\PostFormFilter;
use Zend\ServiceManager\ServiceLocatorInterface;
use Zend\ServiceManager\FactoryInterface;

class PostFormFilterFactory implements FactoryInterface
{
	public function createService(ServiceLocatorInterface $serviceManager)
	{
		$filter = new PostFormFilter();
		$filter->prepareFilters($serviceManager->get('application-categories'));
		return $filter;
	}
}