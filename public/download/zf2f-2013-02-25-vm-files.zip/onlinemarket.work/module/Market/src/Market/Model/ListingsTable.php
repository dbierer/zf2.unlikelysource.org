<?php
namespace Market\Model;

use Market\Form\PostForm;

use Zend\Db\Sql\Expression;
use Zend\Db\TableGateway\TableGateway;
use Zend\Db\Sql\Where;
use Zend\Db\Sql\Select;
use Zend\Db\TableGateway\AbstractTableGateway;

class ListingsTable extends TableGateway
{
	public static $tableName = 'listings';
	public function getTableName()
	{
		return self::$tableName;
	}
	public function getListingsByCategory($category)
	{
		return $this->select(array('category' => $category));
	}
	public function getListingById($id)
	{
		return $this->select(array('listings_id' => $id))->current();
	}
	public function getMostRecentListing()
	{
		$expression = new Expression('MAX(`listings_id`)');
		$selectSub = new Select();
		$selectSub->from(self::$tableName)->columns(array($expression));
		$where = new Where();
		$where->in('listings_id', $selectSub);
		$selectPrime = new Select();
		$selectPrime->from(self::$tableName);
		$selectPrime->where($where);
		echo $selectPrime->getSqlString($this->getAdapter()->getPlatform());
		return $this->selectWith($selectPrime)->current();
	}
	public function addPosting($data)
	{
		list($data['city'], $data['country']) = explode(',', PostForm::$cityCodes[$data['cityCode']]);
		$data['date_expires'] = date('Y-m-d H:i:s', time() + $data['date_expires'] * 24 * 60 * 60);
		unset($data['captcha'], $data['cityCode'], $data['submit']); 
		return $this->insert($data);
	}
}