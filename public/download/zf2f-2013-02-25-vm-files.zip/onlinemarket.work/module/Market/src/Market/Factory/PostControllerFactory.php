<?php
namespace Market\Factory;

use Market\Controller\PostController;
use Zend\ServiceManager\ServiceLocatorInterface;
use Zend\ServiceManager\FactoryInterface;

class PostControllerFactory implements FactoryInterface
{
	public function createService(ServiceLocatorInterface $controllerManager)
	{
		$serviceManager = $controllerManager->getServiceLocator()->get('ServiceManager');
		$controller = new PostController();
		$controller->categories 	= $serviceManager->get('application-categories');
		$controller->postForm		= $serviceManager->get('market-post-form');
		$controller->postFormFilter	= $serviceManager->get('market-post-form-filter');
		$controller->listingsTable	= $serviceManager->get('market-listings-table');
		return $controller;
	}
}