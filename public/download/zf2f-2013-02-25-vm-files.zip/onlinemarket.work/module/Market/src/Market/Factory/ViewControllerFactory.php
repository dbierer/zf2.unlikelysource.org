<?php
namespace Market\Factory;

use Market\Controller\ViewController;
use Zend\ServiceManager\ServiceLocatorInterface;
use Zend\ServiceManager\FactoryInterface;

class ViewControllerFactory implements FactoryInterface
{
	public function createService(ServiceLocatorInterface $controllerManager)
	{
		$serviceManager = $controllerManager->getServiceLocator()->get('ServiceManager');
		$controller = new ViewController();
		$controller->listingsTable = $serviceManager->get('market-listings-table');
		return $controller;
	}
}