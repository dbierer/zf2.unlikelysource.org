Sample module, based on the Zend Skeleton Module, for use in the Zend Framework 2 Fundamentals Course
Assumes that there is a service called "general-adapter" which will give instance of the database adapter for use on this installation.
If you are following the labs, your database connectivity will be configured in /path/to/onlinemarket.work/config/autoload/db.local.php.
This module also assumes there is a database table called "listings".

