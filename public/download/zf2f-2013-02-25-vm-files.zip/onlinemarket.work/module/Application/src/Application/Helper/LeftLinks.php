<?php
namespace Application\Helper;

use Zend\View\Helper\AbstractHelper;

class LeftLinks extends AbstractHelper
{
	public function render($values, $prefix = '')
	{
		$output = '<ul>' . PHP_EOL;
		foreach ($values as $category) {
			$output .= sprintf('<li><a href="%s/%s">%s</a></li>' . PHP_EOL, $prefix, $category, $category);
		}
		$output .= '</ul>' . PHP_EOL;
		return $output;
	}
	public function __invoke($values, $prefix = '')
	{
		if (isset($values) && is_array($values)) {
			return $this->render($values, $prefix);
		} else {
			return '';
		}
	}
}