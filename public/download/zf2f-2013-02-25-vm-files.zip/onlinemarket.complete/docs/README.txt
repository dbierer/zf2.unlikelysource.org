FILE STRUCTURE:

data/* must be writeable by the  web server user (i.e. www-data)
