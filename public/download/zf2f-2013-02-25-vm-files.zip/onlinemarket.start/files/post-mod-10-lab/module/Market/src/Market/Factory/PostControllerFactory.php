<?php

namespace Market\Factory;

use Market\Controller\PostController;
use Zend\ServiceManager\FactoryInterface;
use Zend\ServiceManager\ServiceLocatorInterface;

class PostControllerFactory implements FactoryInterface
{
    public function createService(ServiceLocatorInterface $controllerManager)
    {
        $allServices = $controllerManager->getServiceLocator();
        $sm = $allServices->get('ServiceManager');
        $controller = new PostController();
        $controller->categories 	= $sm->get('categories');
        $controller->postForm 		= $sm->get('market-post-form');
        $controller->postFormFilter = $sm->get('market-post-form-filter');
        $controller->listingsTable	= $sm->get('listings-table');
        return $controller;
    }
}
