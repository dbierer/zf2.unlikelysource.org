<?php
namespace Market\Factory;

use Market\Model\ListingsTable;
use Zend\ServiceManager\FactoryInterface;
use Zend\ServiceManager\ServiceLocatorInterface;

class ListingsTableFactory implements FactoryInterface
{
    public function createService(ServiceLocatorInterface $serviceManager)
    {
    	$tableName = ListingsTable::$tableName;
    	$adapter = $serviceManager->get('general-adapter');
        return new ListingsTable($tableName, $adapter);
    }
}
