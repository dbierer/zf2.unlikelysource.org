<?php
/**
 * Local Configuration Override
 * Call the filename *.local.php and it will be read in
 * See application.config.php line 7
 *
 */

return array(
    'service_manager' => array(
        'services' => array(
            'params' => array(
            	'log_filename' => __DIR__ . '/../../data/logs/items_viewed.log',
            ),
        	'email-params' => array(
        		'to'	=> 'admin@company.com',
        		'from'	=> 'market@company.com',
        		'email_dir' => __DIR__ . '/../../data/logs',
        	),
        ),
    ),
);
