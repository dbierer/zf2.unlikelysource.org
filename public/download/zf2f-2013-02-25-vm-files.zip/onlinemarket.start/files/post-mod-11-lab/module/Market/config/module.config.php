<?php
return array(
    'controllers' => array(
		'aliases' => array(
			'alt' => 'market-view-controller',
		),
    	'invokables' => array(),
    	'factories' => array(
   			'market-post-controller' => 'Market\Factory\PostControllerFactory',
            'market-index-controller' => 'Market\Factory\IndexControllerFactory',
            'market-view-controller' => 'Market\Factory\ViewControllerFactory',
    	),
    ),
	'service_manager' => array(
		'factories' => array(
			'market-post-form' => 'Market\Factory\PostFormFactory',
			'market-post-form-filter' => 'Market\Factory\PostFormFilterFactory',
		    'listings-table' => 'Market\Factory\ListingsTableFactory',
		    'market-mail-transport' => 'Market\Factory\MailTransportFactory',
		),
	),
    'router' => array(
        'routes' => array(
        	'home' => array(
                'type'    => 'Literal',
                'options' => array(
                    'route'    => '/',
                    'defaults' => array(
                        'controller'    => 'market-index-controller',
                        'action'        => 'index',
                    ),
                ),
        	),
        	'market' => array(
                'type'    => 'Literal',
                'options' => array(
                    'route'    => '/market',
                    'defaults' => array(
                        'controller'    => 'market-index-controller',
                        'action'        => 'index',
                    ),
                ),
        	),
        	'market-view' => array(
                'type'    => 'Literal',
                'options' => array(
                    'route'    => '/market/view',
                    'defaults' => array(
                        'controller'    => 'market-view-controller',
                        'action'        => 'index',
                    ),
                ),
                'may_terminate' => true,
                'child_routes' => array(
                    'default' => array(
                        'type'    => 'Segment',
                        'options' => array(
                            'route'    => '/[:action][/][:category]',
                        	'defaults' => array(
                        		'action' => 'index',
                        		'category' => 'general',
                        	),
                        ),
                    ),
                ),
        	),
        	'market-item' => array(
                'type'    => 'Literal',
                'options' => array(
                    'route'    => '/market/item',
                    'defaults' => array(
                        'controller'    => 'market-view-controller',
                        'action'        => 'item',
                    ),
                ),
                'may_terminate' => true,
                'child_routes' => array(
                    'default' => array(
                        'type'    => 'Segment',
                        'options' => array(
                            'route'    => '/[:id]',
                        	'defaults' => array(
                        		'action' => 'item',
                        	),
                        ),
                    ),
                ),
        	),
        	'market-post' => array(
                'type'    => 'Literal',
                'options' => array(
                    'route'    => '/market/post',
                    'defaults' => array(
                        'controller'    => 'market-post-controller',
                        'action'        => 'index',
                    ),
                ),
                'may_terminate' => true,
                'child_routes' => array(
                    'default' => array(
                        'type'    => 'Segment',
                        'options' => array(
                            'route'    => '[/]',
                        ),
                    ),
                ),
        	),
        ),
    ),
    'view_manager' => array(
        'template_path_stack' => array(
            'Market' => __DIR__ . '/../view',
        ),
    ),
);
