<?php
namespace Application\Service;

class AppService
{
	public static $eventsCalled = array('START');
}