<?php
//define('CONTAINER_PASSWORD', 'password');
//$dns = explode('.', $_SERVER['HTTP_HOST']);
//define('CONTAINER', $dns[0]);

return array(
    'service_manager' => array(
        'factories' => array(
            'Zend\Db\Adapter\Adapter' => 'Zend\Db\Adapter\AdapterServiceFactory',
        ),
    ),
    'db' => array(
        'driver'         => 'pdo',
        'dsn'            => 'mysql:dbname=guestbook;host=localhost',
        'username'       => 'zend',
        'password'       => 'password',
        'driver_options' => array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'UTF8'",
        						  PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION),
    ),
);
